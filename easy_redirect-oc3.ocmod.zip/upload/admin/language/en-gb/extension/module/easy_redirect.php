<?php
$_['heading_title'] = 'Easy Redirect';

$_['text_list'] = 'List redirects';
$_['text_not_empty'] = 'Fill in the box!';

$_['column_id'] = 'ID';
$_['column_from'] = 'URL to be redirected';
$_['column_to'] = 'URL redirected to';
$_['column_response'] = 'Response code';
$_['column_used']  = 'Redirected';
$_['column_action']  = 'Action';

?>