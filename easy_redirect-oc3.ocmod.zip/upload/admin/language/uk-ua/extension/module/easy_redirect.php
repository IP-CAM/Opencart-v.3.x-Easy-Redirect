<?php
$_['heading_title'] = 'Easy Redirect - просте рішення для переадресації';

$_['text_list'] = 'Список редиректів';
$_['text_not_empty'] = 'Заповніть поля!';


$_['column_id'] = 'ID';
$_['column_from'] = 'URL з якого переадресовується';
$_['column_to'] = 'URL на який переадресовується';
$_['column_response'] = 'Код відповіді';
$_['column_used']  = 'Здійснено переадресацій';
$_['column_action']  = 'Дія';
?>