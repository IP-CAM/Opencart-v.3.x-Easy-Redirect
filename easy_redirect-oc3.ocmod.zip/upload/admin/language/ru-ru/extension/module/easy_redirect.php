<?php
$_['heading_title'] = 'Easy Redirect - Простое решение для переадрессации';

$_['text_list'] = 'Список редиректов';
$_['text_not_empty'] = 'Заполните поля!';

$_['column_id'] = 'ID';
$_['column_from'] = 'URL который переадресовывается';
$_['column_to'] = 'URL на который редиректит';
$_['column_response'] = 'Код ответа';
$_['column_used']  = 'Переадресовано';
$_['column_action']  = 'Действие';

?>